﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Product_Sale_Project.Entity
{
    public class SaleItem
    {
        [ScaffoldColumn(false)]
        //This is Primary Key
        public int Id { get; set; }

        [Required, StringLength(100), Display(Name = "Sale Name")]
        public string SaleName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int? ProductId { get; set; }
        public virtual Product Product { get; set; }
    }
    public class Product
    {
        [ScaffoldColumn(false)]
        //This is Foreign Key
        public int ProductId { get; set; }

        [Required, StringLength(100), Display(Name = "Product Name")]
        public string Name { get; set; }
        public string Description { get; set; }

        [Required,  Display(Name = "Price")]
        public double Price { get; set; }

        public virtual ICollection<SaleItem> SaleItems { get; set; }

    }
}

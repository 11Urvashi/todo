﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Product_Sale_Project.Data.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
